# -*- coding': 'utf-8 -*-
import requests
import time
import os
import re
import sys
import json
import pandas as pd
import warnings

warnings.filterwarnings('ignore')


text = ['PHO', 'SAS', 'DAL', 'OKC', 'SAC', 'HOU', 'MEM', 'LAL', 'MIN', 'DEN', 'LAC', 'POR', 'UTA', 'GSW', 'NOH', 'MIA', 'DET', 'BOS', 'CLE', 'WAS', 'ORL', 'CHI', 'PHI', 'IND', 'NJN', 'MIL', 'NYK', 'TOR', 'CHA', 'ATL']

# print(len(text))
for j in range(0, len(text)):
    print("第几个了   {}   ".format(j))
    url = 'http://www.stat-nba.com/query_team.php?QueryType=ss&order=1&crtcol=formular&SsType=playoff&Team_id={}&Formular=result_out_wdivideleftbracketresult_out_waddresult_out_lrightbracketmultiply100&PageNum=30'.format(text[j])
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Cookie': '__cfduid=d09d4b3f04f417adc111f85c1c5ce2b001608538052; Hm_lvt_102e5c22af038a553a8610096bcc8bd4=1608538053; yjs_id=fDE2MDg1MzgwNTM1MTk; ctrl_time=1; Hm_lpvt_102e5c22af038a553a8610096bcc8bd4=1608538801',
        'Host': 'www.stat-nba.com',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36 FS'
    }
    print(url)
    response = requests.get(url=url, headers=headers)
    content = response.content.decode('utf-8')
    team_name = re.findall("target='_blank'>(.*?)</a></td>", content)
    # print(len(team_name))
    season = []
    for i in range(len(team_name)):
        if i % 2 == 1:
            season.append(team_name[i])
    # print(season)
    info = []
    # info.append(season)
    for i in range(0, len(season)):
        info_list = re.findall('row{}">(.*?)</td>'.format(str(i)), content)
        # print(info_list)
        del info_list[1]
        del info_list[1]
        # print(info_list)
        info.append(info_list)
    df = pd.DataFrame(info)
    df[0] = season
    print(df)
    df.columns = ['赛季', '投篮', '命中', '出手', '三分', '命中', '出手', '罚球', '命中', '出手', '篮板', '前场', '后场', '助攻', '抢断', '盖帽', '失误', '犯规',
                 '得分', '失分', '胜', '负', '公示']
    df.to_excel('{}.xlsx'.format(text[j]))

# df = df.sort_values(by='赛季', ascending=False)