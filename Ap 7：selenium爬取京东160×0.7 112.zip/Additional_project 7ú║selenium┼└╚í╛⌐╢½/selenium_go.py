# -*- coding: utf-8 -*-
import re
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time

# 打开插件
option = webdriver.ChromeOptions()
option.binary_location = r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
driver = webdriver.Chrome(r'D:\#peiyuan\chromedriver_win32\chromedriver.exe', options=option)

# 加载界面
url = 'https://search.jd.com/Search?keyword=iPhone%20se&enc=utf-8&wq=iPhone%20se&pvid=bb5aceade63c4d739a1639c40be75f0b'
driver.get(url=url)
time.sleep(3)

# 获取页面初始高度
js = "return action=document.body.scrollHeight"
height = driver.execute_script(js)

# 将滚动条调整至页面底部
driver.execute_script('window.scrollTo(0, document.body.scrollHeight)')
time.sleep(5)
# 定义初始时间戳（秒）
t1 = int(time.time())

# 定义循环标识，用于终止while循环
status = True

# 重试次数
num = 0

while status:
    # 获取当前时间戳（秒）
    t2 = int(time.time())
    # 判断时间初始时间戳和当前时间戳相差是否大于30秒，小于30秒则下拉滚动条
    if t2 - t1 < 30:
        new_height = driver.execute_script(js)
        if new_height > height:
            time.sleep(1)
            driver.execute_script('window.scrollTo(0, document.body.scrollHeight)')
            # 重置初始页面高度
            height = new_height
            # 重置初始时间戳，重新计时
            t1 = int(time.time())
    elif num < 3:  # 当超过30秒页面高度仍然没有更新时，进入重试逻辑，重试3次，每次等待30秒
        time.sleep(3)
        num = num + 1
    else:  # 超时并超过重试次数，程序结束跳出循环，并认为页面已经加载完毕！
        print("滚动条已经处于页面最下方！")
        status = False
        # 滚动条调整至页面顶部
        driver.execute_script('window.scrollTo(0, 0)')
        break

content = driver.page_source


price = re.findall('<em>￥</em><i>(.*?)</i>', content, re.S)
title = re.findall('<div class="p-name p-name-type-2">\n\t\t\t\t\t\t\t<a target="_blank" title="(.*?)"', content, re.S)
info = re.findall(';">\n\t\t\t\t\t\t\t\t<em>(.*?)</em>', content, re.S)#运用正则表达式 爬取源代码的中的信息
for i in range(len(info)):
    info[i] = info[i].replace('<font class="skcolor_ljg">', '').replace('</font>', '')
    info[i] = info[i].replace('<span class="p-tag" style="background-color:#01c30b">拍拍</span>\t\n', '')#对数据进行处理
# print(info, len(info), sep='\n')
# print(title, len(title), sep='\n')
# print(price, len(price), sep='\n')//查看爬取内容是否有误

df = pd.DataFrame([info, title,  price]).T
df.columns = ['info', 'title',  'price']
# print(df)
df.to_excel('test2.xlsx', index=False)#将爬取的内容保存至excel表格