# -*- coding: utf-8 -*-
#   -*-   coding:   cp936   -*-  使用中文
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd


# 分解信息
def list_split(content, separator):
    new_list = []
    for i in range(len(content)):
        new_list.append(list(filter(None, content[i].split(separator))))  # 以separator为分隔符
    return new_list


# 清除信息中的空格
def list_replace(content, old, new):
    return [content[i].replace(old, new) for i in range(len(content))]


def find_words(content, pattern):  # 寻找关键词
    return [content[i] for i in range(len(content)) if (pattern in content[i]) == True]


def search_university(content, pattern):  # 寻找大学
    return len([find_words(content[i], pattern) for i in range(len(content))
                if find_words(content[i], pattern) != []])


WXdata = pd.read_excel('PyDm_data.xlsx', 'WXdata');
nG = nx.Graph()  # 创建一个空的图

university = pd.read_excel('PyDm_data.xlsx', 'university');
# university1=sum(university,[])

organ = list_split(WXdata['Organ'], ';')

data1 = pd.DataFrame([[i, search_university(organ, i)] for i in university['学校名称']])

keyword = list_split(WXdata['Keyword'].dropna(axis=0, how='all').tolist(), ';;')
keyword1 = sum(keyword, [])
author = list_replace(WXdata['Author'].dropna(axis=0, how='all').tolist(), ',', ';')
author1 = list_split(author, ';')
author2 = sum(author1, [])
data1;
