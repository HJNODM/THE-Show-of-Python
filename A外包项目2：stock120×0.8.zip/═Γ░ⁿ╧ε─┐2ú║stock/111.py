import pandas as pd

x = [2, 3, 4, 4, 5]
y = [1, 2, 3, 4, 5]
df_revelent = pd.DataFrame({'X': x, 'Y':y})

print(df_revelent)

