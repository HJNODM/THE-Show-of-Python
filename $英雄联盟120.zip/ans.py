# -*- coding:utf-8 -*-
import re
import requests
import pandas as pd
import urllib
import numpy as np
import warnings

false = False
true = True
warnings.filterwarnings("ignore")  # 忽略警告

headers = {
    'Accept': 'application / json, text / javascript, * / *; q = 0.01',
    'Referer': 'https://lol.qq.com/',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="90", "Google Chrome";v="90"',
    'sec-ch-ua-mobile': '?0',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36',
}  # 模拟浏览器登录的请求头，避免被识别为爬虫，


def crawler_heroes_info(url):
    response = requests.get(url=url, headers=headers)  # 获取网址的返回内容
    content = response.content.decode('unicode_escape')  # 将返回的内容以Unicode的方式解码
    content = content.replace('\/', "/")  # 修改部分细节
    # print(content)  # 打印其结果
    content = eval(content)['hero']  # 其转换为dict格式，并获得hero——key下的信息
    df = pd.DataFrame(content)  # 将内容绘制成DataFrame类型
    df.to_excel('heroes_info.xlsx', index=False)  # 以excel格式完成输出


def crawler_heroes_content_info(url, index):
    print(index, '⑧')
    response = requests.get(url=url, headers=headers)  # 获取网址的返回内容
    content = response.content.decode('unicode_escape')  # 将返回的内容以Unicode的方式解码
    content = content.replace('\n', '').replace('\/', "/")  # 修改部分细节
    i = None
    ban = [10, 17, 53, 240]  # 将信息不匹配的内容采取特殊处理
    if index in ban:
        for j in range(len(content)):
            if content[j] == '}':
                i = j
                break
        content = content[:i + 1] + '}'
    content = eval(content)  # 其转换为dict格式，并获得hero——key下的信息
    data_hero = content['hero']
    title = data_hero['name']
    name = data_hero['title']
    info = data_hero['shortBio']
    return name, title, info  # 函数返回取出的字段


def heroes_pic_url(url):
    response = requests.get(url=url, headers=headers)
    content = response.content.decode('unicode_escape')  # 将返回的内容以Unicode的方式解码
    content = content.replace('\/', "/").replace('\n', '')  # 修改部分细节
    # print(content)
    name = re.findall('heroName":".*?","heroTitle":".*?","name":"(.*?)","chromas":"0","chromasBelongId":"0",', content)
    # 获得英雄皮肤所对应的名字
    for i in range(len(name)):
        if len(name[i]) >= 40:
            name[i] = name[i][-40:] + '"'
            name[i] = str(re.findall('"name":"(.*?)"', name[i]))[2:-2]
    # print(name)
    urls = re.findall(',"mainImg":"(.*?)",', content)  # 获得英雄皮肤图片
    url_ans = []
    for it in urls:
        if len(it) != 0:
            url_ans.append(it)
    return url_ans, name


def save_pic(name, urls):
    for i in range(len(urls)):
        print(urls[i])
        if 'K/DA' in name[i]:  # 特殊情况处理
            name[i] = name[i].replace('K/DA', 'KDA')
        if '\\xa0' in name[i]:
            name[i] = name[i].replace('\\xa0', ' ')
        if '阿木木:“主人不要我了”' == name[i]:
            name[i] = '阿木木 主人不要我了'
        try:  # 保存图片，如果因意外报错，直接跳过该图片
            print("保存几张图片了？           {}            {}".format(i + 1, name[i]))
            urllib.request.urlretrieve(urls[i], 'pic/{}.jpg'.format(name[i]))
        except:
            continue


if __name__ == '__main__':
    url_1 = 'https://game.gtimg.cn/images/lol/act/img/js/heroList/hero_list.js'
    url_2 = 'https://game.gtimg.cn/images/lol/act/img/js/hero/{}.js'
    # crawler_heroes_info(url_1)
    df = pd.read_excel("heroes_info.xlsx")
    data = list(df['heroId'])
    ans = []
    name = []
    ans_url = []  # 图片的url——list
    for it in data:
        url = url_2.format(it)  # 每一位英雄的地址链接
        # a, b, c = crawler_heroes_content_info(url, it)  # 获得英雄的个人信息
        # ans.append([a, b, c])
        d, e = heroes_pic_url(url)  # 获取英雄的图片url
        ans_url += d
        name += e
    # print(len(name), len(ans_url))
    save_pic(name, ans_url)  # 以获得的url爬取图片并存入本地
    # df_1 = pd.DataFrame(ans)  # 将内容绘制成DataFrame类型
    # df_1.columns = ['name', 'title', 'info']  # 更改df的列名
    # df_1.to_excel('heroes_per_info.xlsx', index=False)  # 以excel的形式输出
